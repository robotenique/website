#The law of large numbers website
~~Check out the website!~~ (Still not live)

Welcome to the repository for the Law of large numbers website! Here is where we
upload the latest version of the website. Here it is, explained, how it works:

### index.html

Is where you'll find most part of the website. Contains title, wiki at the side,
footer, and buttons for "help" and changing between dice and coin.

---

### iframecoin.html and iframedice.html

Are both iframes that run the graphs. Contains the sliders, buttons and inputs that
make the site fun.

---

### coinGraph.js and diceGraph.js

Are the scripts that run the graph.

---

### randomDice.js

While initially intended to be diceGraph.js, it now runs scripts to open dropdowns
and modals.

---
#### Other stuff used
- **CanvasJS**

  CanvasJS was the library we used to do the dynamic line chart.
- **w3.css**

  w3 CSS was used to make the website look way prettier.
- **animate.css**

  animate is an addition that is both very simple to use and that renders
  very beautiful pop-in animations.
- **jQuery**

  jQuery was used as an addition to javascript, for dealing with lots of tags.
